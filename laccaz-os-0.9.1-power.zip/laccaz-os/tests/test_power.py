import sys
from pathlib import Path
from unittest.mock import patch
from PySide6.QtWidgets import QApplication,QMessageBox
from PySide6.QtCore import QProcess
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r/'config/includes.chroot/usr/share/laccaz'))
from power import PowerRequest
app=QApplication([]);request=PowerRequest()
# Actual poweroff must never be launched on the authoring machine.
with patch.object(request.process,'start') as start,patch.object(QMessageBox,'question',side_effect=AssertionError('Unexpected confirmation')):
 request.request();start.assert_called_once_with('systemctl',['poweroff']);request.request();assert start.call_count==1
with patch.object(QMessageBox,'warning') as warning:
 request.completed(1,QProcess.NormalExit);warning.assert_called_once();assert not request.busy
print('PASS immediate power-off dispatch without confirmation, duplicate guard and denied-request handling; no real shutdown executed')
