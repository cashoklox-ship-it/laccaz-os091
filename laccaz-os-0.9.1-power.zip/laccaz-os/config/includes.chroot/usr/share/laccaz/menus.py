import configparser,json,sys
from pathlib import Path
from PySide6.QtCore import Qt,QProcess,QSize,QTimer,QRectF
from PySide6.QtGui import QIcon,QPixmap,QPainter,QColor,QFont,QPen,QPainterPath,QRegion
from PySide6.QtWidgets import QFrame,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QScrollArea,QWidget,QGridLayout,QToolButton,QListWidget,QListWidgetItem,QStackedWidget
BASE=Path(__file__).parent
POPUP='''QFrame#popover{background:transparent;border:0} QLabel{background:transparent;color:#e6edf7} QLineEdit{background:#222d3e;border:1px solid #34455d;border-radius:12px;padding:13px;color:#ecf4ff} QPushButton{background:#263346;border:0;border-radius:10px;padding:10px;color:#d6e5fa} QPushButton:hover{background:#344964} QPushButton:disabled{color:#75849a} QScrollArea{background:transparent;border:0} QWidget#canvas{background:transparent} QToolTip{background:#222d3e;color:#eff6ff;padding:7px;border:1px solid #465c7a}'''
class Popover(QFrame):
 def __init__(self):
  super().__init__(None,Qt.Popup|Qt.FramelessWindowHint);self.setObjectName('popover');self.setAttribute(Qt.WA_TranslucentBackground);self.setAttribute(Qt.WA_NoMouseReplay);self.setStyleSheet(POPUP)
 def resizeEvent(self,event):
  path=QPainterPath();path.addRoundedRect(QRectF(self.rect()),20,20);self.setMask(QRegion(path.toFillPolygon().toPolygon()));super().resizeEvent(event)
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);p.setBrush(QColor('#171e2a'));p.setPen(QPen(QColor('#354154'),1));p.drawRoundedRect(QRectF(self.rect()).adjusted(.5,.5,-.5,-.5),20,20);p.end()
 def keyPressEvent(self,e):
  if e.key()==Qt.Key_Escape:self.hide()
  else:super().keyPressEvent(e)

def fallback_icon(text):
 pix=QPixmap(56,56);pix.fill(Qt.transparent);p=QPainter(pix);p.setRenderHint(QPainter.Antialiasing);p.setPen(Qt.NoPen);p.setBrush(QColor(['#2c5976','#4f487c','#285f5e','#655047'][sum(map(ord,text))%4]));p.drawRoundedRect(2,2,52,52,16,16);p.setPen(QColor('#e0edff'));p.setFont(QFont('DejaVu Sans',21,QFont.DemiBold));p.drawText(pix.rect(),Qt.AlignCenter,text[:1].upper());p.end();return QIcon(pix)
class ApplicationMenu(Popover):
 def __init__(self,discover,launch):
  super().__init__();self.discover=discover;self.launch=launch;self.entries=[];self.category='Все'
  v=QVBoxLayout(self);v.setContentsMargins(26,24,26,24);v.setSpacing(17)
  head=QHBoxLayout();logo=QLabel();logo.setPixmap(QIcon(str(BASE/'logo.svg')).pixmap(34,34));head.addWidget(logo);label=QLabel('Приложения');label.setStyleSheet('font-size:22px;font-weight:600');head.addWidget(label);head.addStretch();self.count=QLabel();self.count.setStyleSheet('color:#879bb6');head.addWidget(self.count);v.addLayout(head)
  self.search=QLineEdit();self.search.setPlaceholderText('Найти приложение…');self.search.textChanged.connect(self.populate);v.addWidget(self.search)
  nav=QHBoxLayout();nav.setSpacing(7);self.filters={}
  for name in ['Все','Разработка','Интернет','Система']:
   b=QPushButton(name);b.clicked.connect(lambda checked=False,n=name:self.filter(n));nav.addWidget(b);self.filters[name]=b
  nav.addStretch();v.addLayout(nav)
  self.scroll=QScrollArea();self.scroll.setWidgetResizable(True);self.scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff);self.canvas=QWidget();self.canvas.setObjectName('canvas');self.grid=QGridLayout(self.canvas);self.grid.setContentsMargins(0,4,0,4);self.grid.setSpacing(9);self.scroll.setWidget(self.canvas);v.addWidget(self.scroll,1)
  self.note=QLabel('Выбери приложение для запуска');self.note.setStyleSheet('color:#879bb6;font-size:12px');v.addWidget(self.note)
 def reload(self):
  self.entries=[]
  for name,path in self.discover():
   c=configparser.ConfigParser(interpolation=None,strict=False)
   try:c.read(path);entry=c['Desktop Entry'];categories=entry.get('Categories','');icon=QIcon(entry.get('Icon','')) if entry.get('Icon','').startswith('/') else QIcon.fromTheme(entry.get('Icon',''))
   except (OSError,KeyError,configparser.Error):categories='';icon=QIcon()
   if icon.isNull():icon=fallback_icon(name)
   category='Разработка' if 'Development' in categories or 'dev hub' in name.lower() else ('Интернет' if 'Network' in categories else 'Система')
   self.entries.append((name,path,icon,category))
  self.search.clear();self.populate();self.search.setFocus()
 def filter(self,name):self.category=name;self.populate()
 def populate(self):
  while self.grid.count():
   item=self.grid.takeAt(0)
   if item.widget():item.widget().deleteLater()
  for row in range(self.grid.rowCount()):self.grid.setRowStretch(row,0)
  cols=max(3,(self.width()-70)//116);q=self.search.text().casefold();rows=[e for e in self.entries if q in e[0].casefold() and (self.category=='Все' or e[3]==self.category)]
  for i,(name,path,icon,category) in enumerate(rows):
   button=QToolButton();button.setText(name if len(name)<=18 else name[:16]+'…');button.setToolTip(name);button.setIcon(icon);button.setIconSize(QSize(42,42));button.setToolButtonStyle(Qt.ToolButtonTextUnderIcon);button.setFixedSize(108,100);button.setCursor(Qt.PointingHandCursor);button.setStyleSheet('QToolButton{background:transparent;border:1px solid transparent;border-radius:14px;color:#dbe7f8;padding:8px;font-size:11px} QToolButton:hover{background:#25344a;border:1px solid #3d5879} QToolButton:pressed{background:#344e70}');button.clicked.connect(lambda checked=False,p=path:self.activate(p));self.grid.addWidget(button,i//cols,i%cols)
  self.grid.setRowStretch((len(rows)+cols-1)//cols,1);self.count.setText(str(len(rows)));self.note.setText('Ничего не найдено' if not rows else 'Нажми на значок • Escape — закрыть')
  for name,b in self.filters.items():b.setStyleSheet('background:#3b5678;color:#edf5ff' if name==self.category else 'background:#222c3b;color:#93a8c3')
 def activate(self,path):
  if self.launch('gio',['launch',path]):self.hide()
  else:self.note.setText('Не удалось запустить приложение.')

class ControlMenu(Popover):
 def __init__(self,launch,show_windows):
  super().__init__();self.launch=launch;self.proc=None;self.mode='';self.networks=[];self.setFixedWidth(390)
  v=QVBoxLayout(self);v.setContentsMargins(22,22,22,20);v.setSpacing(13);title=QLabel('Пункт управления');title.setStyleSheet('font-size:20px;font-weight:600');v.addWidget(title)
  self.pages=QStackedWidget();self.pages.setStyleSheet('QStackedWidget{background:transparent;border:0}');v.addWidget(self.pages);main=QWidget();main.setObjectName('canvas');m=QVBoxLayout(main);m.setContentsMargins(0,0,0,0);m.setSpacing(10)
  wifi=QPushButton('Wi-Fi     →');wifi.clicked.connect(self.show_wifi);m.addWidget(wifi)
  for name,command in [('Звук и устройства',['pavucontrol']),('Открыть Dev Hub',['laccaz-devhub'])]:
   b=QPushButton(name);b.clicked.connect(lambda checked=False,c=command:self.external(c));m.addWidget(b)
  b=QPushButton('Обзор окон');b.clicked.connect(lambda:(self.hide(),show_windows()));m.addWidget(b);m.addSpacing(5);hint=QLabel('Escape или нажатие за пределами — закрыть');hint.setStyleSheet('font-size:11px;color:#879bb6');m.addWidget(hint);self.pages.addWidget(main)
  wifi_page=QWidget();wifi_page.setObjectName('canvas');w=QVBoxLayout(wifi_page);w.setContentsMargins(0,0,0,0);w.setSpacing(10);row=QHBoxLayout();back=QPushButton('←');back.clicked.connect(lambda:self.pages.setCurrentIndex(0));row.addWidget(back);b=QPushButton('Обновить сети');b.clicked.connect(self.scan);row.addWidget(b,1);w.addLayout(row)
  radio=QHBoxLayout()
  for title,value in [('Включить Wi-Fi','on'),('Выключить','off')]:
   b=QPushButton(title);b.clicked.connect(lambda checked=False,x=value:self.radio(x));radio.addWidget(b)
  w.addLayout(radio);self.status=QLabel('Поиск сетей…');self.status.setWordWrap(True);self.status.setStyleSheet('color:#94accb;font-size:12px');w.addWidget(self.status)
  self.list=QListWidget();self.list.setFixedHeight(218);self.list.setStyleSheet('QListWidget{background:#1d2736;border:1px solid #344359;border-radius:12px;padding:5px} QListWidget::item{padding:11px;border:0;color:#dce9fa} QListWidget::item:selected{background:#344f71;color:white;border-radius:7px} QListWidget::item:hover{background:#293d57;border-radius:7px}');self.list.currentRowChanged.connect(self.selected);w.addWidget(self.list)
  self.password=QLineEdit();self.password.setEchoMode(QLineEdit.Password);self.password.setPlaceholderText('Пароль сети (для новой сети)');self.password.returnPressed.connect(self.connect_network);w.addWidget(self.password);self.connect_button=QPushButton('Подключиться');self.connect_button.clicked.connect(self.connect_network);w.addWidget(self.connect_button);b=QPushButton('Дополнительные настройки');b.clicked.connect(lambda:self.external(['nm-connection-editor']));w.addWidget(b);self.pages.addWidget(wifi_page);self.pages.currentChanged.connect(lambda index:self.setFixedHeight(640 if index else 310));self.setFixedHeight(310)
 def external(self,command):self.hide();self.launch(command[0],command[1:])
 def show_wifi(self):self.pages.setCurrentIndex(1);self.scan()
 def selected(self,*args):
  index=self.list.currentRow();a=self.networks[index] if 0<=index<len(self.networks) else None;self.password.clear();self.password.setVisible(bool(a and a['security'] not in ('','--') and not a['active']));self.connect_button.setEnabled(bool(a and not a['active'] and self.proc is None));self.connect_button.setText('Подключено' if a and a['active'] else 'Подключиться')
 def run(self,program,args,payload=None,mode='scan'):
  if self.proc:return
  p=QProcess(self);self.proc=p;self.mode=mode;p.finished.connect(lambda code,state:self.finished(p,code));p.errorOccurred.connect(lambda e:self.failed(p,e));p.start(program,args)
  if payload is not None:p.write(json.dumps(payload,ensure_ascii=False).encode());p.closeWriteChannel()
  self.connect_button.setEnabled(False)
 def scan(self):
  if self.proc:return
  self.status.setText('Ищем доступные сети…');self.run('/usr/bin/python3',[str(BASE/'wifi_backend.py'),'scan'])
 def radio(self,value):self.run('nmcli',['radio','wifi',value],mode='radio')
 def connect_network(self):
  index=self.list.currentRow()
  if self.proc or not 0<=index<len(self.networks):return
  a=self.networks[index]
  if '802.1X' in a['security']:self.status.setText('Корпоративная сеть: открой дополнительные настройки.');return
  payload=dict(a,password=self.password.text());self.password.clear();self.status.setText('Подключение к '+a['ssid']+'…');self.run('/usr/bin/python3',[str(BASE/'wifi_backend.py'),'connect'],payload,'connect')
 def failed(self,p,error):
  if error==QProcess.FailedToStart:self.proc=None;self.status.setText('Не удалось запустить сетевую службу.');p.deleteLater();self.selected()
 def finished(self,p,code):
  mode=self.mode;output=bytes(p.readAllStandardOutput()).decode(errors='replace');self.proc=None;p.deleteLater()
  if mode=='radio':self.status.setText('Wi-Fi переключён.' if code==0 else 'Не удалось переключить Wi-Fi.');self.scan();return
  try:data=json.loads(output)
  except ValueError:data={'ok':False,'error':'Сетевая служба не ответила.'}
  if not data.get('ok'):self.status.setText(data.get('error','Подключение не удалось.'));self.selected();return
  if mode=='scan':
   self.networks=data['data'];self.list.clear()
   for a in self.networks:self.list.addItem(('✓  ' if a['active'] else '')+a['ssid']+'   '+str(a['signal'])+'%'+('  •' if a['security'] not in ('','--') else ''))
   self.status.setText('Выбери сеть. IP и DNS определяются автоматически.' if self.networks else 'Сети не найдены. Включи Wi-Fi; при отсутствии адаптера проверь драйвер и аппаратный переключатель.')
   if self.networks:self.list.setCurrentRow(0)
   self.selected()
  else:self.status.setText('Подключено.');self.scan()
 def shutdown(self):
  if self.proc:
   p=self.proc;self.proc=None;p.finished.disconnect();p.errorOccurred.disconnect();p.kill();p.waitForFinished(500)
