#!/usr/bin/python3
import configparser, os, shutil, sys
from pathlib import Path
from PySide6.QtCore import Qt,QTimer,QProcess,QDateTime,QUrl,QSize,QSocketNotifier,QSettings,QLocale,QDate,QPoint,QRectF
from PySide6.QtGui import QPainter,QColor,QPen,QFont,QDesktopServices,QLinearGradient,QPainterPath,QRegion,QPixmap,QImage,QIcon
from PySide6.QtWidgets import QApplication,QWidget,QVBoxLayout,QHBoxLayout,QLabel,QPushButton,QLineEdit,QListWidget,QListWidgetItem,QStackedWidget,QMessageBox,QCheckBox,QFrame,QSizePolicy,QCalendarWidget,QFileDialog
from appearance import STYLE, Titlebar, dock_icon,DockButton
from menus import ApplicationMenu,ControlMenu

def start(program,args=[]):
 ok=QProcess.startDetached(program,args)
 return ok[0] if isinstance(ok,tuple) else ok

def applications():
 found={}
 roots=[Path.home()/'.local/share/applications',Path('/usr/local/share/applications'),Path('/usr/share/applications')]
 seen=set()
 for root in roots:
  for p in sorted(root.glob('**/*.desktop')):
   desktop_id=str(p.relative_to(root)).replace('/','-')
   if desktop_id in seen:continue
   seen.add(desktop_id)
   try:
    c=configparser.ConfigParser(interpolation=None,strict=False);c.read(p);e=c['Desktop Entry']
    if e.get('Type')!='Application' or e.get('NoDisplay','false')=='true' or e.get('Hidden','false')=='true':continue
    if 'OnlyShowIn' in e and not any(x in ('Laccaz','KDE') for x in e['OnlyShowIn'].split(';')):continue
    if 'Laccaz' in e.get('NotShowIn','').split(';'):continue
    if e.get('TryExec') and not shutil.which(e['TryExec']):continue
    name=e.get('Name[ru]',e.get('Name',p.stem));found[desktop_id]=(name,str(p))
   except Exception:continue
 return sorted(found.values(),key=lambda x:x[0].casefold())
class GlassPanel(QFrame):
 def __init__(self,backdrop,parent=None):
  super().__init__(parent);self.backdrop=backdrop;self.setAttribute(Qt.WA_TranslucentBackground)
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);path=QPainterPath();path.addRoundedRect(QRectF(self.rect()).adjusted(1,1,-1,-1),12,12);p.setClipPath(path)
  origin=self.backdrop.mapFromGlobal(self.mapToGlobal(QPoint(0,0)));p.drawPixmap(self.rect(),self.backdrop.blurred(),self.rect().translated(origin));p.fillPath(path,QColor(22,24,29,225));p.setClipping(False);p.setPen(QPen(QColor(255,255,255,30),1));p.drawPath(path);p.end()
class Dock(QFrame):
 def __init__(self,backdrop):
  super().__init__();self.setAttribute(Qt.WA_TranslucentBackground)
 def resizeEvent(self,event):
  path=QPainterPath();path.addRoundedRect(QRectF(self.rect()),24,24);self.setMask(QRegion(path.toFillPolygon().toPolygon()));super().resizeEvent(event)
 def paintEvent(self,event):
  p=QPainter(self);p.setRenderHint(QPainter.Antialiasing);g=QLinearGradient(0,0,0,self.height());g.setColorAt(0,QColor(36,40,49,245));g.setColorAt(1,QColor(19,23,30,245));p.setBrush(g);p.setPen(QPen(QColor(255,255,255,38),1));p.drawRoundedRect(QRectF(self.rect()).adjusted(0.5,0.5,-0.5,-0.5),24,24);p.end()
class Backdrop(QWidget):
 def __init__(self):
  super().__init__();self.settings=QSettings('Laccaz','Desktop');self.image=QPixmap();self.cached=None;self.blur_cache=None;self.load_wallpaper(self.settings.value('wallpaper',str(Path(__file__).with_name('night-wallpaper.png'))))
 def load_wallpaper(self,path):
  if str(path).endswith('/coast-wallpaper.png'):path=str(Path(__file__).with_name('night-wallpaper.png'))
  image=QPixmap(path)
  if image.isNull():image=QPixmap(str(Path(__file__).with_name('night-wallpaper.png')))
  self.image=image;self.cached=None;self.blur_cache=None;self.update()
 def resizeEvent(self,e):self.cached=None;self.blur_cache=None;super().resizeEvent(e)
 def wallpaper(self):
  if self.cached is None:
   scaled=self.image.scaled(self.size(),Qt.KeepAspectRatioByExpanding,Qt.SmoothTransformation);self.cached=scaled.copy(max(0,(scaled.width()-self.width())//2),max(0,(scaled.height()-self.height())//2),self.width(),self.height())
  return self.cached
 def blurred(self):
  if self.blur_cache is None:self.blur_cache=self.wallpaper().scaled(max(1,self.width()//22),max(1,self.height()//22),Qt.IgnoreAspectRatio,Qt.SmoothTransformation).scaled(self.size(),Qt.IgnoreAspectRatio,Qt.SmoothTransformation)
  return self.blur_cache
 def paintEvent(self,event):
  p=QPainter(self);p.drawPixmap(0,0,self.wallpaper());p.end()
class Shell:
 def __init__(self,preview=False):
  self.preview=preview;self.folder=Path.home();self.history=[];self.apps=applications();self.root=Backdrop();self.root.setWindowTitle('Laccaz Surface');self.root.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnBottomHint);self.root.setAttribute(Qt.WA_X11NetWmWindowTypeDesktop)
  geo=QApplication.primaryScreen().geometry();self.root.setGeometry(geo)
  self.panel=Dock(self.root);self.panel.setWindowTitle('Laccaz Tasks');self.panel.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint|Qt.WindowDoesNotAcceptFocus);self.panel.setAttribute(Qt.WA_X11NetWmWindowTypeDock);self.panel.setAttribute(Qt.WA_ShowWithoutActivating);self.panel.setFixedHeight(48)
  rail=QHBoxLayout(self.panel);rail.setContentsMargins(9,6,9,6);rail.setSpacing(2)
  self.pins=[];self.pin_windows={};self.pin_cycle={}
  for key,index,tip,fn,tokens in [('apps',0,'Приложения',lambda:self.show('apps'),[]),('browser',7,'Firefox',self.browser,['firefox']),('files',2,'Файлы',self.files,['dolphin']),('terminal',3,'Терминал',lambda:start('konsole'),['konsole']),('hub',1,'Dev Hub',lambda:start('laccaz-devhub'),['dev hub','laccaz-devhub']),('store',6,'Центр приложений',lambda:start('laccaz-appcenter'),['laccaz app center','laccaz-appcenter','центр приложений']),('clips',4,'Буфер обмена',lambda:self.show('clips'),[])]:
   bt=DockButton(QIcon(str(Path(__file__).with_name('logo.svg'))) if key=='apps' else dock_icon('',index),tip);bt.clicked.connect(lambda checked=False,k=key,f=fn:self.open_pin(k,f));rail.addWidget(bt);self.pins.append((key,bt,tokens))
  self.task_separator=QFrame();self.task_separator.setFixedSize(1,18);self.task_separator.setStyleSheet('background:rgba(255,255,255,35)');rail.addWidget(self.task_separator);self.task_separator.hide()
  self.tasks=QWidget();self.tasks.setStyleSheet('background:transparent');self.taskrow=QHBoxLayout(self.tasks);self.taskrow.setContentsMargins(0,0,0,0);self.taskrow.setSpacing(2);rail.addWidget(self.tasks);self.tasks.hide()
  self.task_ids=[];self.task_query=None;self.position_panel()
  self.bar=QFrame(self.root);self.bar.setObjectName('topbar');self.bar.setWindowTitle('Laccaz Menu');self.bar.setWindowFlags(Qt.Window|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint);self.bar.setAttribute(Qt.WA_X11NetWmWindowTypeDock);self.bar.setGeometry(geo.x(),geo.y(),geo.width(),32);self.bar.setStyleSheet('QFrame#topbar{background:#14161b;border:0;border-radius:0} QLabel{background:transparent;color:#e8eaed;font-size:12px;font-weight:600} QPushButton{color:#e8eaed;border:0;background:transparent;padding:3px 8px;border-radius:0} QPushButton:hover{background:#34373f}')
  menu=QHBoxLayout(self.bar);menu.setContentsMargins(10,0,10,0);menu.setSpacing(0)
  left=QWidget();left.setStyleSheet('background:transparent');left.setFixedWidth(min(360,geo.width()//3));links=QHBoxLayout(left);links.setContentsMargins(0,0,0,0);links.setSpacing(0)
  for name,fn in [('Laccaz',lambda:self.show('apps')),('Проекты',lambda:self.show('projects')),('Окна',lambda:self.show('windows'))]:
   bt=QPushButton(name);bt.clicked.connect(fn);links.addWidget(bt)
   if name=='Laccaz':bt.setIcon(QIcon(str(Path(__file__).with_name('logo.svg'))));bt.setIconSize(QSize(18,18))
  links.addStretch();menu.addWidget(left);menu.addStretch();self.clock=QPushButton();self.clock.clicked.connect(self.calendar);self.clock.setStyleSheet('font-weight:600');menu.addWidget(self.clock);menu.addStretch()
  right=QWidget();right.setStyleSheet('background:transparent');right.setFixedWidth(left.width());links=QHBoxLayout(right);links.setContentsMargins(0,0,0,0);links.setSpacing(0);links.addStretch()
  for name,fn in [('Обои',self.choose_wallpaper),('Управление',self.controls),('Выход',self.logout)]:
   bt=QPushButton(name);bt.clicked.connect(fn);links.addWidget(bt)
  menu.addWidget(right)
  self.launcher=ApplicationMenu(applications,start);self.control_panel=ControlMenu(start,lambda:self.show('windows'))
  self.drawer=QWidget();self.drawer.setWindowTitle('Laccaz Search');self.drawer.setWindowFlags(Qt.Tool|Qt.FramelessWindowHint|Qt.WindowStaysOnTopHint);self.drawer.resize(min(710,geo.width()-40),min(660,geo.height()-150));self.drawer.move(geo.x()+(geo.width()-self.drawer.width())//2,geo.y()+65)
  d=QVBoxLayout(self.drawer);d.setContentsMargins(24,18,24,24);d.setSpacing(14);d.addWidget(Titlebar(self.drawer,'Laccaz'));self.title=QLabel();self.title.setObjectName('brand');d.addWidget(self.title)
  self.search=QLineEdit();self.search.setPlaceholderText('Поиск…');self.search.textChanged.connect(self.populate);d.addWidget(self.search)
  self.list=QListWidget();self.list.itemActivated.connect(self.activate);self.list.itemClicked.connect(self.activate);d.addWidget(self.list)
  self.pause=QCheckBox('Пауза записи буфера');d.addWidget(self.pause)
  self.clearbutton=QPushButton('Очистить историю и системный буфер');self.clearbutton.clicked.connect(self.clear);d.addWidget(self.clearbutton)
  self.note=QLabel();self.note.setWordWrap(True);self.note.setObjectName('muted');d.addWidget(self.note)
  QApplication.clipboard().dataChanged.connect(self.clip_changed)
  self.timer=QTimer();self.timer.timeout.connect(self.tick);self.timer.start(1000);self.tick();self.root.show();self.panel.show();self.bar.show();self.create_widgets();self.task_timer=QTimer();self.task_timer.timeout.connect(self.refresh_tasks);self.task_timer.start(1800);QApplication.instance().aboutToQuit.connect(self.cleanup_tasks)
  if not preview:
   from surface_ipc import listen
   try:
    self.ipc,self.lock=listen();self.notifier=QSocketNotifier(self.ipc.fileno(),QSocketNotifier.Read);self.notifier.activated.connect(self.receive)
   except OSError as error:print('Surface shortcuts unavailable:',error,file=sys.stderr)
   QApplication.primaryScreen().geometryChanged.connect(self.relayout)
  if not preview:QTimer.singleShot(100,self.properties)
 def cleanup_tasks(self):
  self.task_timer.stop()
  if hasattr(self,'control_panel'):self.control_panel.shutdown()
  if self.task_query:
   p=self.task_query;self.task_query=None;p.finished.disconnect();p.errorOccurred.disconnect();p.kill();p.waitForFinished(500)
 def refresh_tasks(self):
  if self.preview or self.task_query is not None:return
  p=QProcess(self.panel);self.task_query=p;p.finished.connect(lambda code,state:self.tasks_result(p,code));p.errorOccurred.connect(lambda e:self.tasks_error(p,e));p.start('wmctrl',['-lx'])
 def tasks_error(self,p,error):
  if error==QProcess.FailedToStart:self.task_query=None;p.deleteLater()
 def tasks_result(self,p,code):
  text=bytes(p.readAllStandardOutput()).decode(errors='replace');self.task_query=None;p.deleteLater()
  if code==0:self.update_tasks(text)
 def position_panel(self):
  self.panel.adjustSize();geo=QApplication.primaryScreen().geometry();self.panel.move(geo.x()+(geo.width()-self.panel.width())//2,geo.bottom()-self.panel.height()-11)
  if hasattr(self,'bar') and self.root.isVisible():self.panel.show();self.panel.raise_()
 def open_pin(self,key,fallback):
  windows=self.pin_windows.get(key,[])
  if windows:
   index=self.pin_cycle.get(key,0)%len(windows);start('wmctrl',['-ia',windows[index]]);self.pin_cycle[key]=index+1
  else:fallback()
 def update_tasks(self,text):
  rows=[];own={int(w.winId()) for w in (self.root,self.panel,self.bar,self.drawer)};self.pin_windows={}
  for line in text.splitlines():
   parts=line.split(None,4)
   if len(parts)!=5:continue
   try:wid=int(parts[0],16);desktop=int(parts[1])
   except ValueError:continue
   if wid in own or desktop<0:continue
   matched=False;identity=(parts[2]+' '+parts[4]).casefold()
   for key,button,tokens in self.pins:
    if tokens and any(t in identity for t in tokens):self.pin_windows.setdefault(key,[]).append(parts[0]);matched=True;break
   if not matched:rows.append((parts[0],parts[4]))
  for key,button,tokens in self.pins:button.running=bool(self.pin_windows.get(key));button.update()
  limit=min(4,max(0,(QApplication.primaryScreen().geometry().width()-330)//40));rows=rows[:limit]
  if rows==self.task_ids:self.position_panel();return
  self.task_ids=rows
  while self.taskrow.count():
   item=self.taskrow.takeAt(0)
   widget=item.widget()
   if widget:widget.setParent(None);widget.deleteLater()
  for wid,title in rows:
   button=DockButton(dock_icon('',5),title);button.running=True;button.clicked.connect(lambda checked=False,w=wid:start('wmctrl',['-ia',w]));self.taskrow.addWidget(button)
  self.tasks.setVisible(bool(rows));self.task_separator.setVisible(bool(rows));self.position_panel()
 def choose_wallpaper(self):
  path,_=QFileDialog.getOpenFileName(self.root,'Выбрать обои',str(Path.home()),'Изображения (*.png *.jpg *.jpeg *.webp)')
  if path:
   if QPixmap(path).isNull():QMessageBox.warning(self.root,'Обои','Не удалось прочитать изображение.');return
   self.root.settings.setValue('wallpaper',path);self.root.load_wallpaper(path);self.panel.update();self.bar.update()
   for w in self.widgets:w.update()
 def create_widgets(self):
  # Keep the desktop clear; the calendar opens from the centered clock.
  self.widgets=[]
 def files(self):
  if not start('dolphin'):self.show('files')
 def browser(self):
  if not start('firefox-esr'):
   QMessageBox.warning(self.panel,'Браузер','Firefox ESR не найден. Установи его через Центр приложений.')
 def calendar(self):
  if not hasattr(self,'calendar_window'):
   self.calendar_window=QWidget();self.calendar_window.setWindowTitle('Laccaz Calendar');self.calendar_window.setWindowFlags(Qt.Tool|Qt.FramelessWindowHint);v=QVBoxLayout(self.calendar_window);v.addWidget(Titlebar(self.calendar_window,'Календарь'));v.addWidget(QCalendarWidget());self.calendar_window.resize(480,400)
  self.calendar_window.show();self.calendar_window.raise_();self.calendar_window.activateWindow()
 def receive(self,*args):
  while True:
   try:action=self.ipc.recv(64).decode()
   except BlockingIOError:break
   if action=='desktop':start('wmctrl',['-k','on'])
   elif action=='files':self.files()
   elif action in ('apps','clips','projects','windows'):self.show(action)
 def relayout(self,*args):
  geo=QApplication.primaryScreen().geometry();self.root.setGeometry(geo);self.bar.setGeometry(geo.x(),geo.y(),geo.width(),32);self.position_panel();self.properties()
 def controls(self):
  if self.control_panel.isVisible():self.control_panel.hide();return
  geo=QApplication.primaryScreen().geometry();self.control_panel.pages.setCurrentIndex(0);self.control_panel.adjustSize();self.control_panel.move(geo.right()-self.control_panel.width()-16,geo.top()+44);self.control_panel.show();self.control_panel.raise_()
 def properties(self):
  if not os.environ.get('DISPLAY'):return
  def prop(widget,key,kind,value):start('xprop',['-id',str(int(widget.winId())),'-f',key,kind,'-set',key,value])
  prop(self.panel,'_NET_WM_STRUT_PARTIAL','32c',f'0, 0, 0, 60, 0, 0, 0, 0, 0, 0, 0, {self.root.width()-1}')
  prop(self.bar,'_NET_WM_STRUT_PARTIAL','32c',f'0, 0, 32, 0, 0, 0, 0, 0, 0, {self.root.width()-1}, 0, 0');self.root.lower();self.panel.raise_();self.bar.raise_()
 def tick(self):
  now=QDateTime.currentDateTime();self.clock.setText(QLocale('ru_RU').toString(now,'ddd, d MMM   hh:mm'))
  if hasattr(self,'date_label'):self.date_label.setText(QLocale('ru_RU').toString(now,'dddd').upper());self.day_label.setText(now.toString('d'));self.time_label.setText(now.toString('hh:mm'))
 def home(self):self.drawer.hide();start('wmctrl',['-k','on'])
 def show(self,mode):
  if mode=='apps':
   if self.launcher.isVisible():self.launcher.hide();return
   self.drawer.hide();geo=QApplication.primaryScreen().geometry();self.launcher.resize(min(810,geo.width()-36),min(640,geo.height()-116));self.launcher.move(geo.x()+(geo.width()-self.launcher.width())//2,geo.y()+max(44,(geo.height()-self.launcher.height())//2-20));self.launcher.reload();self.launcher.show();self.launcher.search.setFocus();return
  self.launcher.hide()
  self.mode=mode;self.search.clear();self.title.setText({'apps':'Приложения','clips':'Буфер обмена','projects':'Проекты','windows':'Окна','files':'Файлы'}[mode]);self.pause.setVisible(mode=='clips');self.clearbutton.setVisible(mode=='clips');self.populate();self.drawer.show();self.drawer.raise_();self.drawer.activateWindow();self.search.setFocus()
 def populate(self):
  if not hasattr(self,'mode'):return
  self.list.clear();q=self.search.text().casefold();rows=[]
  if self.mode=='apps':self.apps=applications();rows=[(n,p) for n,p in self.apps];self.note.setText('Поиск установленных приложений. Запуск по нажатию.')
  elif self.mode=='clips':rows=[(s,s) for s in self.history];self.note.setText('Только текст • до 40 записей в памяти • на диск не сохраняется. Выбери фрагмент, затем вставь Ctrl+V. Для паролей включай паузу.')
  elif self.mode=='files':
   self.note.setText(str(self.folder)+' • выбери папку или файл')
   try:rows=[('↑ На уровень выше',str(self.folder.parent))]+[(('▸ ' if p.is_dir() else '')+p.name,str(p)) for p in sorted(self.folder.iterdir(),key=lambda p:(not p.is_dir(),p.name.casefold())) if not p.name.startswith('.')]
   except OSError as e:self.note.setText(str(e));rows=[]
  elif self.mode=='projects':
   root=Path.home()/'Projects';root.mkdir(exist_ok=True);rows=[(p.name,str(p)) for p in sorted(root.iterdir()) if p.is_dir()];rows.insert(0,('+ Создать проект в Dev Hub','NEW'));self.note.setText('Проекты из ~/Projects. Выбор открывает папку.')
  else:
   self.note.setText('Выбери окно для переключения. Alt+Tab также работает.');self.windows();return
  for label,value in rows:
   if q in label.casefold():item=QListWidgetItem(label[:180]);item.setData(Qt.UserRole,value);self.list.addItem(item)
 def windows(self):
  p=QProcess(self.drawer);p.finished.connect(lambda code,status:self.window_result(p));p.start('wmctrl',['-l'])
 def window_result(self,p):
  if self.mode=='windows':
   for line in bytes(p.readAllStandardOutput()).decode(errors='replace').splitlines():
    parts=line.split(None,3)
    if len(parts)==4 and not parts[3].startswith('Laccaz ') and self.search.text().casefold() in parts[3].casefold():
     it=QListWidgetItem(parts[3]);it.setData(Qt.UserRole,parts[0]);self.list.addItem(it)
  p.deleteLater()
 def activate(self,item):
  value=item.data(Qt.UserRole)
  if self.mode=='apps':
   if not start('gio',['launch',value]):QMessageBox.warning(self.drawer,'Запуск','Не удалось запустить приложение.');return
  elif self.mode=='clips':QApplication.clipboard().setText(value)
  elif self.mode=='files':
   p=Path(value)
   if p.is_dir():self.folder=p;self.search.clear();self.populate();return
   QDesktopServices.openUrl(QUrl.fromLocalFile(value))
  elif self.mode=='projects':
   if value=='NEW':start('laccaz-devhub')
   else:QDesktopServices.openUrl(QUrl.fromLocalFile(value))
  else:start('wmctrl',['-ia',value])
  self.drawer.hide()
 def clip_changed(self):
  if self.pause.isChecked():return
  mime=QApplication.clipboard().mimeData()
  if not mime or mime.hasFormat('x-kde-passwordManagerHint') or not mime.hasText():return
  s=mime.text()
  if not s.strip() or len(s)>20000:return
  if s in self.history:self.history.remove(s)
  self.history.insert(0,s);del self.history[40:]
  if self.drawer.isVisible() and getattr(self,'mode','')=='clips':self.populate()
 def clear(self):self.history.clear();QApplication.clipboard().clear();self.populate()
 def logout(self):
  if QMessageBox.question(self.panel,'Завершить сеанс','Закрыть оболочку и выйти из сеанса?')==QMessageBox.Yes:QApplication.quit()
if __name__=='__main__':
 app=QApplication(sys.argv);app.setQuitOnLastWindowClosed(False);QIcon.setThemeName('breeze-dark');app.setStyle('Fusion');app.setStyleSheet(STYLE);app.setWindowIcon(QIcon(str(Path(__file__).with_name('logo.svg'))));shell=Shell('--preview' in sys.argv);sys.exit(app.exec())
